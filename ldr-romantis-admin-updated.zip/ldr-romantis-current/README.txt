OUR LITTLE UNIVERSE — LDR WEBSITE

FILES
- index.html : halaman publik
- admin.html : panel admin yang sudah diperbarui

SETUP FIREBASE
1. Buka Firebase Console dan pilih project Anda.
2. Aktifkan Realtime Database.
3. Salin konfigurasi Web App dari Project settings > Your apps.
4. Isi objek firebaseConfig di index.html dan admin.html dengan konfigurasi project yang sama.
5. Pastikan databaseURL memakai URL database project lengkap yang terlihat di Firebase Console.
6. Jalankan lewat server lokal (mis. VS Code Live Server) untuk pengujian, bukan file://.

FITUR ADMIN
- Dashboard ringkasan foto, bucket list, dan waktu penyimpanan.
- Form untuk mengatur konten yang digunakan index.html.
- Pratinjau URL foto, editor bucket list, indikator koneksi, dan notifikasi penyimpanan.
- Simpan data ke path Realtime Database: ldr/config (serta ldr/bucketList untuk kompatibilitas).

PENTING — KEAMANAN
Login yang ada di versi ini masih demo sisi browser dan BUKAN pengamanan sungguhan. Jangan mengandalkan login ini untuk melindungi data pribadi. Sebelum website dipublikasikan, aktifkan Firebase Authentication (Email/Password), ubah panel agar menggunakan autentikasi Firebase, dan batasi Realtime Database dengan Security Rules sehingga hanya admin terautentikasi yang dapat menulis. Jangan gunakan public read/write rules.

Catatan: Custom JavaScript disimpan sebagai data saja dan tidak otomatis dieksekusi. Upload ImgBB memerlukan API key; link unggahan dapat bersifat publik. Layanan hosting video pihak ketiga bisa berubah atau menghapus file.
